#1723467622
journalctl -u nginx --since '30 min ago' --no-pager | tail -20
#1723477694
systemctl status nginx --no-pager
#1723477724
journalctl -u nginx --since '30 min ago' --no-pager | tail -20
#1723477911
ss -ltnp | grep nginx
#1723485509
systemctl is-active nginx
#1723485515
systemctl status https --no-pager
#1723485523
journalctl -u nginx -n 200 --no-pager
#1723485579
ss -ltnp | grep https
#1723485616
systemctl show nginx -p ActiveState -p SubState -p MainPID
#1723487805
ls -ltr /var/log/ | tail -10
#1723488006
last -20
#1723488810
cat /etc/fstab
#1723488855
lsblk
#1723488888
cat /etc/os-release
#1723488901
pwd
#1723488987
find /etc/systemd/user -maxdepth 2 -type f 2>/dev/null | head
#1723489029
hostname
#1723489079
journalctl -u nginx --since '30 min ago' --no-pager | tail -20
#1723489090
systemd-analyze blame | head
#1723489140
ls -la
#1723489261
last -5
#1723489267
grep -i warning /var/log/syslog | tail
#1723489315
pps
#1723489403
nmcli connection show --active
#1723489481
ps -ef | head
#1723489486
cat /etc/hostname
#1723489491
umask
#1723498155
ls -lah
#1723498163
history | tail -15
#1723498543
ip route get 8.8.8.8
#1723499242
systemctl list-timers --all --no-pager | head
#1723499321
dmesg --ctime | tail -20
#1723500973
journalctl -u https -n 20 --no-pager
#1723501156
ps aux | grep nginx
#1723501298
systemctl show https -p ActiveState -p SubState -p MainPID
#1723501624
env | sort | head
#1723502377
cat /proc/cpuinfo | grep 'model name' | head -1
#1723502909
grep -i error /var/log/syslog | tail -100
#1723503125
w
#1723503135
sysctl -a 2>/dev/null | grep net.ipv4.ip_forward
#1723503222
groups
#1723503478
journalctl -u https -n 50
#1723505053
journalctl -u nginx -n 20
#1723505422
cat /etc/passwd | head
#1723505677
ls -lah /tmp | head
#1723506013
ss -ltnp | grep nginx
#1723506367
grep -i failed /var/log/auth.log | tail
#1723512315
journalctl -u https --since '30 min ago' --no-pager | tail -100
#1723512367
systemctl show nginx -p ActiveState -p SubState -p MainPID
#1723513560
cd /var/log
#1723513603
journalctl -u nginx -n 100
#1723517397
grep -i failed /var/log/auth.log | tail
#1723517572
df -h
#1723518046
systemctl restart nginx
#1723518084
journalctl -u nginx -n 50
#1723518088
journalctl -u https -n 20
#1723518106
journalctl -u https -n 50
#1723518251
journalctl -u nginx -n 50
#1723518338
ps aux | grep https
#1723518346
journalctl -u nginx -n 100
#1723518406
find /var/log -name '*.gz' -mtime +30 | wc -l
#1723518694
ls -ltr /var/log | tail
#1723518705
last -5
#1723518731
cat /etc/resolv.conf
#1723519299
journalctl -u https -n 200
#1723520135
cat /etc/resolv.conf
#1723520219
journalctl -u https -n 20
#1723520348
grep -i warning /var/log/syslog | tail
#1723520392
grep -i 'session opened' /var/log/auth.log | tail -10
#1723520488
ls /tmp
#1723528252
journalctl -u https -n 200 --no-pager
#1723528335
echo $SHELL
#1723528404
journalctl -u nginx -n 20
#1723528600
lsmod | head
#1723530939
ss -ltnp | grep https
#1723530954
who -a
#1723531259
ps aux --sort=-%mem | head
#1723531567
clear
#1723531612
journalctl -u nginx -n 200
#1723531763
grep -i error /var/log/syslog | tail
#1723542536
ps aux | grep nginx
#1723542963
ls -ld /var/log
#1723543005
journalctl -u nginx -n 100
#1723543059
journalctl -u https -n 100
#1723545692
ss -ltnp | grep https
#1723545704
journalctl -u nginx --since '30 min ago' --no-pager | tail -20
#1723545839
cd /var/log
#1723546007
uptime
#1723546048
journalctl -u https -n 20
#1723546118
ls /tmp
#1723546211
journalctl -u nginx -n 20
#1723546285
systemctl restart https
#1723546351
htop
#1723546389
du -sh /var/log
#1723546439
journalctl -u nginx -n 200
#1723546441
ls -ld /var/log
#1723546459
journalctl -u nginx -n 100
#1723546523
systemctl restart nginx
#1723546562
journalctl -u https -n 20
#1723546611
ps aux | grep https
#1723546845
systemctl list-timers --all --no-pager | head
#1723546968
df -h /var
#1723547033
du -sh /home/* 2>/dev/null | head
#1723547068
grep -i error /var/log/syslog | tail
#1723547071
last -20
#1723547343
journalctl -u nginx --since '30 min ago' --no-pager | tail -100
#1723547567
ps aux --sort=-%mem | head
#1723547657
systemctl list-timers
#1723547904
cat /etc/passwd | head
#1723547979
ip route
#1723548162
find /tmp -maxdepth 1 -type f | head
#1723548732
journalctl -u https -n 50
#1723548740
hostname -f
#1723549089
uswrs
#1723550214
ls
#1723550267
ls -lt /var/log | head
