#1723475712
/bin/bash -c 'whoami; id; uname -a; hostname'
