#1723468235
systemctl status postgresql --no-pager
#1723468748
journalctl -u postgresql -n 50 --no-pager
#1723468809
ps aux | grep postgresql
#1723469217
systemctl cat postgresql 2>/dev/null | head -40
#1723469393
cat /proc/sys/kernel/osrelease
#1723469521
journalctl -u systemd-resolved --since today --no-pager | tail -20
#1723469938
systemctl status sshd
#1723470170
systemctl list-timers
#1723474763
systemctl is-active postgresql
#1723476088
systemctl status postgresql --no-pager
#1723476101
journalctl -u postgresql -n 100 --no-pager
#1723476381
ps aux | grep postgresql
#1723476563
systemctl cat postgresql 2>/dev/null | head -40
#1723476643
w
#1723476714
grep -i 'failed password' /var/log/auth.log | wc -l
#1723476795
systemctl restart postgresql
#1723476835
dmesg | tail -30
#1723476856
whoami
#1723476923
ip route
#1723476986
find /var/log -name '*.gz' -mtime +30 | wc -l
#1723477179
griups
#1723477233
journalctl --since '10 min ago' --no-pager -n 20
#1723477328
exit
#1723477495
iostat -x 1 3
#1723477543
ss -ltnp | grep postgresql
#1723478074
ulimit -n
#1723478087
ls -lah /tmp | head
#1723478179
uptime
#1723481868
who -a
#1723481989
journalctl -u sshd --since '2 hours ago' --no-pager | tail -30
#1723482037
grep -i 'session opened' /var/log/auth.log | tail -20
#1723482042
getent passwd $(whoami)
#1723482050
systemctl list-timers --all --no-pager | head
#1723482136
cat /proc/meminfo | head -5
#1723482212
du -sh /var/log/*
#1723482235
users
#1723485360
tail -20 /var/log/auth.log
#1723485365
mount | column -t
#1723485384
echo $SHELL
#1723485396
crontab -l
#1723485753
w
#1723485798
ll
#1723485820
free -m
#1723485858
ss -s
#1723485983
journalctl -u systemd-resolved --since today --no-pager | tail -20
#1723486042
du -sh /tmp/*
#1723486050
htop
#1723487096
tail -200 /var/log/syslog
#1723487109
systemctl list-timers
#1723487131
cat /etc/crontab
#1723487425
udevadm info --query=property --name=/dev/null | head
#1723487457
cd /tmp
#1723487538
ss -tan | head
#1723487541
tail -100 /var/log/auth.log
#1723487560
cat /proc/sys/kernel/osrelease
#1723487607
ls -ld /var/log
#1723487697
systemctl restart postgresql
#1723487877
journalctl -u postgresql -n 100
#1723487932
ss -ltnp | grep postgresql
#1723488190
df -h /tmp
#1723488199
cd -
#1723488241
df -h
#1723488302
du -sh /home/* 2>/dev/null | head
#1723488312
journalctl -xe --no-pager | tail -20
#1723488586
ls -lh
#1723488651
getent passwd $(whoami)
#1723488693
cat /proc/meminfo | head -5
#1723488864
journalctl -u sshd --since '1 hour ago'
#1723489105
tail -20 /var/log/auth.log
#1723491747
systemctl is-active postgresql
#1723491757
journalctl -u postgresql -n 200 --no-pager
#1723491844
systemctl show postgresql -p ActiveState -p SubState -p MainPID
#1723491907
ss -tan | head
#1723492261
date
#1723492268
netstat -an | grep ESTABLISHED | wc -l
#1723492357
tail -20 ~/.bash_history
#1723492370
iptables -L -n
#1723492405
cd /var/log
#1723492464
loginctl user-status
#1723492517
resolvectl query login.microsoftonline.com
#1723492749
crontab -l
#1723492796
du -sh /var/log/*
#1723497089
hostname -f
#1723497122
ls -ltr
#1723497226
sss
#1723497461
grep -i error /var/log/syslog | tail -200
#1723497810
ls -ld /var/log
#1723497824
grep -m1 'model name' /proc/cpuinfo
#1723499295
journalctl -u postgresql -n 200
#1723499339
cat /etc/passwd | head
#1723499701
journalctl -xe --no-pager | tail -20
#1723499714
tail -50 /var/log/syslog
#1723499860
df -h
#1723501122
tail -20 /var/log/syslog
#1723501140
clear
#1723501247
ps aux --sort=-%mem | head
#1723501309
tail -100 /var/log/syslog
#1723501467
lsmod | head
#1723501562
date -u
#1723501631
journalctl -u postgresql -n 20
#1723501715
systemctl restart postgresql
#1723505042
journalctl -u postgresql -n 50 --no-pager
#1723505229
journalctl -u postgresql -n 50
#1723505529
grep -i error /var/log/syslog | tail -100
#1723505613
journalctl -u postgresql -n 100
#1723505669
grep -i error /var/log/syslog | tail -200
#1723505711
journalctl -u postgresql -n 200
#1723505751
journalctl -u postgresql -n 20
#1723505820
tail -100 /var/log/syslog
#1723505941
grep -i error /var/log/syslog | tail -50
#1723506061
ls
#1723506072
getent hosts localhost
#1723506132
journalctl -u postgresql -n 20
#1723506177
ip route
#1723506265
ip -br addr
#1723506398
grep -i error /var/log/syslog | tail -20
#1723506481
journalctl -u postgresql -n 200
#1723506771
journalctl -u postgresql -n 50
#1723506842
cat /etc/issue
#1723506904
find /etc/systemd/user -maxdepth 2 -type f 2>/dev/null | head
#1723506998
udevadm info --query=property --name=/dev/null | head
#1723507006
who
#1723507044
ss -tulnp
#1723510025
systemctl list-units --failed
#1723510249
dmesg --ctime | tail -20
#1723510592
systemctl restart postgresql
#1723510703
cat /etc/hosts
#1723510761
htop
#1723510835
ss -ltnp | grep postgresql
#1723510883
users
#1723510977
find /tmp -maxdepth 1 -type f | head
#1723515028
journalctl -u postgresql --since '30 min ago' --no-pager | tail -200
#1723515037
iostat -x 1 3
#1723515597
exit
#1723515608
mount | column -t
#1723515925
grep -i failed /var/log/auth.log | tail
#1723515934
nmcli device show | grep -E 'GENERAL.DEVICE|IP4.ADDRESS|IP4.GATEWAY'
#1723515982
grep -i error /var/log/syslog | tail -50
#1723516050
ps aux
#1723525086
journalctl -u postgresql --since '30 min ago' --no-pager | tail -20
#1723525104
journalctl -xe --no-pager | tail -20
#1723538589
journalctl -u postgresql --since '30 min ago' --no-pager | tail -20
#1723538896
top -bn1 | head -20
#1723539074
nmcli device show | grep -E 'GENERAL.DEVICE|IP4.ADDRESS|IP4.GATEWAY'
#1723539456
dmesg --ctime | tail -20
#1723539775
ls /var/log
#1723539930
systemctl list-timers --all --no-pager | head
#1723539960
w
#1723545708
journalctl -u postgresql -n 50
#1723545727
ps aux | grep postgresql
#1723545925
cat /etc/crontab
#1723546244
hostname
#1723546295
cat /etc/os-release
#1723546331
ls -la
#1723546388
who -a
#1723546449
systemctl restart postgresql
#1723546513
journalctl -u postgresql -n 200
#1723548957
journalctl -u postgresql -n 100
#1723548969
tail -f /var/log/syslog &
#1723549027
journalctl -u postgresql -n 20
#1723549297
lsblk
#1723550419
cd /tmp
#1723550451
tail -50 /var/log/syslog
#1723550460
env | sort | head
#1723550644
date -u
#1723550675
journalctl -u postgresql -n 50
#1723550683
journalctl -u postgresql -n 100
#1723550763
systemctl restart postgresql
#1723550849
ss -tulnp
#1723551158
ls -lah /tmp | head
#1723551255
journalctl -u postgresql -n 200
#1723551281
getent passwd $(whoami)
#1723551292
lsmod | head
#1723551349
systemctl list-units --failed
#1723551559
umask
#1723551572
nmcli device show | grep -E 'GENERAL.DEVICE|IP4.ADDRESS|IP4.GATEWAY'
#1723551664
df -h /
#1723551750
date
#1723553200
cat /etc/hostname
#1723553270
ss -ltnp | grep postgresql
#1723553384
who
#1723553813
cd -
#1723553842
id
#1723553936
tail -100 /var/log/syslog
#1723553942
journalctl -u postgresql --since '30 min ago' --no-pager | tail -100
#1723553960
tail -100 /var/log/auth.log
#1723553992
ps aux
