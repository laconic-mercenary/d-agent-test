#1723468040
ssh -A priya.desai@DB-01.solsticeoutdoors.com
#1723468261
/usr/sbin/sshd -D
#1723468299
/usr/sbin/rsyslogd -n
#1723469049
dbus-daemon --system --address=systemd:
#1723469329
code --no-sandbox /home/priya.desai/projects/api-server
#1723469376
nano /home/priya.desai/repos/infra-config/main.py
#1723469426
/usr/sbin/atd -f
#1723469725
last -20
#1723469851
date -u
#1723470270
systemctl status packagekit --no-pager
#1723470313
systemctl status cups --no-pager
#1723470431
vmstat 1 5
#1723471608
ssh -l priya.desai FILE-01.solsticeoutdoors.com
#1723473853
psql -U postgres -d warehouse
#1723473873
systemd --user
#1723473902
/usr/sbin/cron -f
#1723473972
/usr/sbin/NetworkManager --no-daemon
#1723473985
redis-cli GET session:active_count
#1723474446
ssh -o ServerAliveInterval=30 priya.desai@DB-01.solsticeoutdoors.com
#1723474732
ssh -o ConnectTimeout=10 priya.desai@WEB-01.solsticeoutdoors.com
#1723475612
ssh -i ~/.ssh/work_ed25519 priya.desai@DB-01.solsticeoutdoors.com
#1723476585
dbus-daemon --system --address=systemd:
#1723476813
code --no-sandbox /home/priya.desai/src/monitoring
#1723477071
vim /home/priya.desai/src/monitoring/server.go
#1723477193
ssh priya.desai@WEB-01
#1723477238
/usr/sbin/rsyslogd -n
#1723477429
/usr/sbin/sshd -D
#1723477440
ldapsearch -x -H ldap://WEB-01.solsticeoutdoors.com -b "dc=solsticeoutdoors,dc=com" "(objectClass=user)"
#1723477461
mysql --defaults-extra-file=~/.my.cnf appdb
#1723477479
psql -U postgres -d warehouse
#1723477506
/usr/sbin/NetworkManager --no-daemon
#1723478102
systemctl is-active apache2
#1723478367
journalctl -u redis --since '30 min ago' --no-pager | tail -200
#1723478493
/usr/sbin/cron -f
#1723478668
redis-cli KEYS "cache:*" | head -20
#1723479206
firefox -P default
#1723479263
curl -X GET https://jira.solsticeoutdoors.com/browse/PROJ-4539 -H 'Accept: application/json'
#1723479290
ssh -i ~/.ssh/id_rsa priya.desai@WEB-01
#1723479385
ssh -A priya.desai@DB-01.solsticeoutdoors.com
#1723479931
ssh -l priya.desai FILE-01.solsticeoutdoors.com
#1723481400
ssh priya.desai@DB-01.solsticeoutdoors.com
#1723481814
systemd --user
#1723481887
/usr/sbin/NetworkManager --no-daemon
#1723481966
vim /home/priya.desai/projects/api-server/main.py
#1723482026
vim /opt/company/webapp/config.yaml
#1723482085
/usr/sbin/sshd -D
#1723482262
redis-cli GET session:active_count
#1723482320
/usr/sbin/sshd -D
#1723482497
/usr/sbin/cron -f
#1723482611
/usr/sbin/sshd -D
#1723482646
ldapsearch -x -H ldap://FILE-01 -b "dc=solsticeoutdoors,dc=com" "(objectClass=computer)"
#1723482925
curl -X GET https://gitlab.solsticeoutdoors.com/team/project/-/pipelines/1740 -H 'Accept: application/json'
#1723482951
ldapsearch -x -H ldap://10.70.20.10 -b "dc=solsticeoutdoors,dc=com" "(objectClass=computer)"
#1723482981
nano /home/priya.desai/repos/infra-config/deploy.sh
#1723483033
nano /home/priya.desai/src/monitoring/requirements.txt
#1723483111
vim /home/priya.desai/projects/api-server/main.py
#1723483194
code --no-sandbox /home/priya.desai/projects/data-pipeline
#1723483242
/usr/sbin/NetworkManager --no-daemon
#1723483284
code --no-sandbox /home/priya.desai/projects/data-pipeline
#1723483332
mysql --defaults-extra-file=~/.my.cnf inventory
#1723483362
docker images
#1723483422
dbus-daemon --system --address=systemd:
#1723483513
tail -200 /var/log/auth.log
#1723484127
whoami
#1723484436
uname -a
#1723484443
apt-cache policy slack-desktop 2>/dev/null
#1723484507
find /tmp -maxdepth 1 -type f | head
#1723482237
ssh -i ~/.ssh/work_ed25519 priya.desai@DB-01.solsticeoutdoors.com
#1723484600
systemd --user
#1723484826
ssh -l priya.desai WEB-01.solsticeoutdoors.com
#1723484996
/usr/sbin/NetworkManager --no-daemon
#1723485053
vim /home/priya.desai/projects/api-server/Makefile
#1723485075
ssh -o ServerAliveInterval=30 priya.desai@DB-01
#1723485110
psql -U postgres -d metrics
#1723485121
journalctl -u sshd --since '2 hours ago' --no-pager | tail -30
#1723485138
grep -i 'session opened' /var/log/auth.log | tail -20
#1723485148
tail -20 ~/.bash_history
#1723485199
grep -m1 'model name' /proc/cpuinfo
#1723485323
ssh priya.desai@WEB-01.solsticeoutdoors.com
#1723486843
ssh priya.desai@DB-01.solsticeoutdoors.com
#1723486843
systemctl status postfix --no-pager
#1723486997
journalctl -u nginx --since '30 min ago' --no-pager | tail -50
#1723487372
ss -ltnp | grep cron
#1723487466
systemctl show redis -p ActiveState -p SubState -p MainPID
#1723487546
ssh -o ConnectTimeout=10 priya.desai@WEB-01
#1723488773
ssh -o ConnectTimeout=10 priya.desai@FILE-01.solsticeoutdoors.com
#1723488952
ssh priya.desai@WEB-01
#1723490275
ssh priya.desai@FILE-01
#1723491104
ssh -o ConnectTimeout=10 priya.desai@DB-01.solsticeoutdoors.com
#1723491931
hostname
#1723492217
cat /etc/fstab
#1723492383
systemctl status packagekit --no-pager
#1723492439
who
#1723492683
id
#1723493301
ssh -tt priya.desai@FILE-01.solsticeoutdoors.com
#1723493702
journalctl --since '10 min ago' --no-pager -n 20
#1723493796
systemctl status fwupd --no-pager
#1723495008
ssh priya.desai@10.70.20.10
#1723496703
ssh -i ~/.ssh/work_ed25519 priya.desai@DB-01.solsticeoutdoors.com
#1723497649
ssh -tt priya.desai@WEB-01.solsticeoutdoors.com
#1723498305
flatpak list 2>/dev/null | head
#1723498508
ls -lah ~/.config 2>/dev/null | head
#1723498600
grep -i 'session opened' /var/log/auth.log | tail -10
#1723498665
journalctl --no-pager -n 5
#1723499864
apt-cache policy google-chrome-stable 2>/dev/null
#1723499980
ls -lh
#1723500405
ssh priya.desai@WEB-01
#1723500713
ssh priya.desai@10.70.10.20
#1723502125
journalctl -u redis -n 50
#1723502331
cd /tmp
#1723502625
journalctl -u apache2 --since '30 min ago' --no-pager | tail -20
#1723502730
systemctl restart postfix
#1723502983
journalctl -u postfix -n 100
#1723504480
ssh -o ConnectTimeout=10 priya.desai@DB-01
#1723504723
ssh -o ConnectTimeout=10 priya.desai@FILE-01.solsticeoutdoors.com
#1723504816
ssh priya.desai@WEB-01
#1723506035
env | sort | head
#1723506075
snap list 2>/dev/null | head
#1723506218
stat /etc/passwd
#1723507310
ssh priya.desai@FILE-01.solsticeoutdoors.com
#1723507547
cd ~
#1723507639
apt-cache policy slack-desktop 2>/dev/null
#1723507779
last -5
#1723509692
ssh -tt priya.desai@DB-01.solsticeoutdoors.com
#1723512157
ssh -A priya.desai@10.70.10.10
#1723512306
systemctl restart redis
#1723512563
grep -i error /var/log/syslog | tail
#1723512757
systemctl restart docker
#1723512923
cat /etc/os-release
#1723513634
ssh -A priya.desai@FILE-01.solsticeoutdoors.com
#1723514539
ssh -i ~/.ssh/id_ed25519 priya.desai@DB-01.solsticeoutdoors.com
#1723515039
ssh priya.desai@FILE-01
#1723515271
ssh -tt priya.desai@10.70.10.10
#1723516617
journalctl -p warning --since '1 hour ago' --no-pager | tail -20
#1723516963
du -sh ~/Downloads 2>/dev/null
#1723517219
ssh priya.desai@WEB-01
#1723517698
ssh -i ~/.ssh/work_ed25519 priya.desai@FILE-01.solsticeoutdoors.com
#1723520670
ssh -tt priya.desai@FILE-01.solsticeoutdoors.com
#1723520759
ps aux | grep redis
#1723520944
ls -lah ~/.local/share 2>/dev/null | head
#1723521888
systemctl is-active docker
#1723522058
journalctl -u nginx -n 200 --no-pager
#1723524695
ssh priya.desai@DB-01.solsticeoutdoors.com
#1723526658
systemctl restart cron
#1723526805
ls -lah ~/.config 2>/dev/null | head
#1723527063
flatpak list 2>/dev/null | head
#1723527356
ps aux | grep sshd
#1723527535
systemctl status cups --no-pager
#1723527910
ssh priya.desai@WEB-01
#1723528351
ssh priya.desai@DB-01.solsticeoutdoors.com
#1723528667
ssh -o ServerAliveInterval=30 priya.desai@FILE-01.solsticeoutdoors.com
#1723530813
ssh priya.desai@WEB-01.solsticeoutdoors.com
#1723533539
ssh -i ~/.ssh/id_ed25519 priya.desai@DB-01
#1723534331
systemctl status docker --no-pager
#1723534342
ssh -i ~/.ssh/work_ed25519 priya.desai@FILE-01.solsticeoutdoors.com
#1723534412
journalctl -u apache2 --since '30 min ago' --no-pager | tail -200
#1723534465
ps aux | grep postfix
#1723535393
systemctl cat redis 2>/dev/null | head -40
#1723535421
find ~/Downloads -maxdepth 1 -type f 2>/dev/null | head
#1723535766
ssh -A priya.desai@10.70.20.10
#1723536127
psql -U postgres -d warehouse
#1723536147
curl -X GET https://jira.solsticeoutdoors.com/browse/PROJ-5386 -H 'Accept: application/json'
#1723536165
systemd --user
#1723536236
/usr/sbin/atd -f
#1723536248
vim /home/priya.desai/projects/data-pipeline/Makefile
#1723536304
code --no-sandbox /home/priya.desai/repos/infra-config
#1723536349
nano /home/priya.desai/projects/api-server/config.yaml
#1723536872
ssh priya.desai@FILE-01.solsticeoutdoors.com
#1723537050
systemctl status cron --no-pager
#1723537121
journalctl -u nginx -n 20 --no-pager
#1723537205
ss -ltnp | grep apache2
#1723537385
systemctl show mysql -p ActiveState -p SubState -p MainPID
#1723538482
ssh -o ServerAliveInterval=30 priya.desai@DB-01.solsticeoutdoors.com
#1723539660
dbus-daemon --system --address=systemd:
#1723539913
/usr/sbin/NetworkManager --no-daemon
#1723539951
redis-cli GET session:active_count
#1723540000
mysql --defaults-extra-file=~/.my.cnf inventory
#1723540026
psql -U postgres -d postgres
#1723540044
mysql --defaults-extra-file=~/.my.cnf wordpress
#1723540073
nano /home/priya.desai/projects/api-server/requirements.txt
#1723540124
/usr/sbin/NetworkManager --no-daemon
#1723540153
firefox --new-tab https://wiki.solsticeoutdoors.com/display/ENG/Architecture
#1723540482
ldapsearch -x -H ldap://DB-01 -b "dc=solsticeoutdoors,dc=com" "(objectClass=user)"
#1723540548
vim /home/priya.desai/projects/api-server/requirements.txt
#1723540615
nano /home/priya.desai/src/monitoring/main.py
#1723540669
code --no-sandbox /home/priya.desai/repos/infra-config
#1723540715
vim /home/priya.desai/projects/api-server/main.py
#1723540799
code --no-sandbox /home/priya.desai/projects/data-pipeline
#1723540844
code --no-sandbox /home/priya.desai/projects/api-server
#1723540899
code --no-sandbox /home/priya.desai/projects/api-server
#1723540946
/usr/sbin/sshd -D
#1723541007
/usr/sbin/cron -f
#1723541067
psql -U postgres -d warehouse
#1723541099
/usr/sbin/cron -f
#1723541137
find ~/Downloads -maxdepth 1 -type f 2>/dev/null | head
#1723541255
snap list 2>/dev/null | head
#1723541341
apt-cache policy slack-desktop 2>/dev/null
#1723542088
ssh -tt priya.desai@FILE-01.solsticeoutdoors.com
#1723542101
ssh -l priya.desai 10.70.10.10
#1723542537
ps aux | grep apache2
#1723543326
ssh -i ~/.ssh/id_ed25519 priya.desai@WEB-01
#1723544748
ssh -o ServerAliveInterval=30 priya.desai@FILE-01
#1723545052
ssh -o ConnectTimeout=10 priya.desai@WEB-01
#1723545230
ssh -tt priya.desai@10.70.10.20
#1723545282
/usr/sbin/rsyslogd -n
#1723545411
nano /home/priya.desai/projects/api-server/index.js
#1723545458
/usr/sbin/NetworkManager --no-daemon
#1723545467
systemd --user
#1723545556
redis-cli MONITOR
#1723545936
ldapsearch -x -H ldap://DB-01 -b "dc=solsticeoutdoors,dc=com" "(objectClass=computer)"
#1723545970
ldapsearch -x -H ldap://FILE-01 -b "dc=solsticeoutdoors,dc=com" "(objectClass=user)"
#1723546317
psql -U postgres -d metrics
#1723546341
systemd --user
#1723546396
ssh priya.desai@FILE-01
#1723546465
dbus-daemon --system --address=systemd:
#1723546860
dbus-daemon --system --address=systemd:
#1723546872
/usr/sbin/rsyslogd -n
#1723546912
nano /home/priya.desai/src/monitoring/deploy.sh
#1723546989
vim /opt/company/webapp/deploy.sh
#1723547056
nano /home/priya.desai/repos/infra-config/index.js
#1723547145
code --no-sandbox /home/priya.desai/projects/api-server
#1723547198
ldapsearch -x -H ldap://FILE-01 -b "dc=solsticeoutdoors,dc=com" "(objectClass=user)"
#1723547371
systemctl status apache2 --no-pager
#1723548622
journalctl -u docker --since '30 min ago' --no-pager | tail -100
#1723548993
ss -ltnp | grep redis
#1723549051
systemctl cat docker 2>/dev/null | head -40
#1723546992
ssh -i ~/.ssh/id_rsa priya.desai@10.70.10.10
#1723547597
ssh priya.desai@FILE-01
#1723548250
ssh -o ServerAliveInterval=30 priya.desai@DB-01
#1723550177
du -sh ~/Downloads 2>/dev/null
#1723550292
ls -lah ~/.local/share 2>/dev/null | head
#1723551631
ssh priya.desai@DB-01.solsticeoutdoors.com
#1723552310
ssh -o ServerAliveInterval=30 priya.desai@FILE-01.solsticeoutdoors.com
#1723552894
ssh -o ConnectTimeout=10 priya.desai@FILE-01
#1723553025
ps aux | grep docker
#1723553092
ssh -A priya.desai@10.70.10.20
#1723553215
ls -lah ~/.config 2>/dev/null | head
#1723553308
find ~/Downloads -maxdepth 1 -type f 2>/dev/null | head
