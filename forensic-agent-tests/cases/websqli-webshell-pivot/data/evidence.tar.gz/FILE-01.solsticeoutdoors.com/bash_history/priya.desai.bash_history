#1723472279
tail -50 /var/log/syslog
#1723472432
journalctl -u samba --since '30 min ago' --no-pager | tail -20
#1723472692
loginctl session-status
#1723472751
cat /proc/cpuinfo | grep 'model name' | head -1
#1723473764
grep -i 'failed password' /var/log/auth.log | wc -l
#1723473827
iptables -L -n
#1723474151
cd ~
#1723474172
netstat -an | grep ESTABLISHED | wc -l
#1723474255
ps aux --sort=-%mem | head
#1723474283
cat /etc/crontab
#1723474293
who -a
#1723474385
systemctl restart samba
#1723474626
ps -ef
#1723474654
ls -la
#1723474663
sl
#1723480325
systemctl is-active samba
#1723480625
journalctl -u samba -n 200 --no-pager
#1723480631
ps aux | grep samba
#1723480872
systemctl cat samba 2>/dev/null | head -40
#1723480894
journalctl -u samba -n 20
#1723481227
df -h /var
#1723481309
tail -f /var/log/syslog &
#1723481601
cd ~
#1723481661
du -sh /tmp/*
#1723481717
resolvectl query company.okta.com
#1723481739
grep -i 'failed password' /var/log/auth.log | wc -l
#1723481959
systemctl list-timers
#1723482054
df -h /
#1723490919
tail -200 /var/log/auth.log
#1723490927
echo $SHELL
#1723491005
hostname -f
#1723491017
tail -200 /var/log/syslog
#1723491196
dmesg --ctime | tail -20
#1723491279
grep -i error /var/log/syslog | tail -50
#1723491366
free -h
#1723491445
ss -tulnp
#1723491843
udevadm info --query=property --name=/dev/null | head
#1723491854
journalctl -u samba -n 200
#1723491914
systemctl restart samba
#1723492052
ls -ltr /var/log | tail
#1723492144
journalctl -p err --no-pager -n 10
#1723492187
ss -ltnp | grep samba
#1723495337
systemctl status samba --no-pager
#1723495436
journalctl -u samba --since '30 min ago' --no-pager | tail -50
#1723495709
ps aux | grep samba
#1723496132
systemctl cat samba 2>/dev/null | head -40
#1723496194
df -h /var
#1723496195
systemctl is-active samba
#1723496205
pwd
#1723496214
journalctl -u samba -n 50 --no-pager
#1723496242
systemctl show samba -p ActiveState -p SubState -p MainPID
#1723496281
sysctl -a 2>/dev/null | grep net.ipv4.ip_forward
#1723496338
htop
#1723496378
journalctl -u samba -n 20
#1723504873
journalctl -u samba -n 200 --no-pager
#1723505334
ss -ltnp | grep samba
#1723505358
systemctl restart samba
#1723505725
ss -ltnp | grep samba
#1723505915
journalctl -u samba -n 100
#1723506003
journalctl -u samba -n 200
#1723506055
hostname -f
#1723506067
date
#1723506111
groups
#1723506304
date -u
#1723506352
journalctl -u samba --since '30 min ago' --no-pager | tail -20
#1723507545
journalctl -u samba --since '30 min ago' --no-pager | tail -50
#1723507562
resolvectl query company.okta.com
#1723507931
tail -50 /var/log/syslog
#1723508005
journalctl -u samba -n 100
#1723508062
ls -la
#1723508206
journalctl -u sshd --since '1 hour ago'
#1723508233
ss -s
#1723508644
journalctl -u samba -n 50
#1723508699
journalctl -u samba -n 20
#1723509038
locale
#1723509048
uptime
#1723509079
journalctl -u samba -n 50
#1723509087
ls -lah /tmp | head
#1723509142
journalctl -u samba -n 50
#1723509215
journalctl -u samba -n 200
#1723509246
ls /var/log
#1723513755
journalctl -u samba -n 20 --no-pager
#1723513792
systemctl show samba -p ActiveState -p SubState -p MainPID
#1723514049
users
#1723517782
journalctl -u samba --since '30 min ago' --no-pager | tail -100
#1723517940
ps aux | grep samba
#1723517945
ls -ltr
#1723517957
grep -i error /var/log/syslog | tail -100
#1723518054
systemctl restart samba
#1723518086
id
#1723518118
du -sh /var/log/*
#1723518184
ls -lh
#1723518198
tail -20 /var/log/syslog
#1723518290
ss -ltnp | grep samba
#1723521065
journalctl -u samba -n 50 --no-pager
#1723521229
env | sort | head
#1723521251
sysctl -a 2>/dev/null | grep net.ipv4.ip_forward
#1723521302
cd -
#1723521467
journalctl -u samba -n 100
#1723521515
top -bn1 | head -20
#1723521879
ls /tmp
#1723522237
pw
#1723535836
ls -lah
#1723535838
journalctl -u samba -n 100 --no-pager
#1723535850
du -sh /home/* 2>/dev/null | head
#1723536083
ss -tan | head
#1723536133
tail -100 /var/log/syslog
#1723536211
stat /etc/passwd
#1723536289
netstat -an | grep ESTABLISHED | wc -l
#1723536385
ss -ltnp | grep samba
#1723536413
cat /etc/fstab
#1723536607
exit
#1723536617
find /var/log -name '*.gz' -mtime +30 | wc -l
#1723536889
who
#1723537130
cd /tmp
#1723537528
systemctl restart samba
#1723537689
cat /etc/resolv.conf
#1723537855
date -u
#1723538603
journalctl -u samba -n 100
#1723538687
ps -ef | head
#1723538752
journalctl -u samba --since '30 min ago' --no-pager | tail -20
#1723538802
grep -i 'session opened' /var/log/auth.log | tail -10
#1723538906
ss -s
#1723538944
ss -tulnp
#1723538954
grep -i error /var/log/syslog | tail -100
#1723538984
iostat -x 1 3
#1723542657
grep -i error /var/log/syslog | tail -50
#1723542982
ps aux
#1723543066
journalctl -u samba -n 20
#1723543175
grep -m1 'model name' /proc/cpuinfo
#1723546768
df -h
#1723546771
journalctl -u samba --since '30 min ago' --no-pager | tail -200
#1723546779
top -bn1 | head -20
#1723548232
cat /etc/hosts
#1723548251
journalctl -u samba --since '30 min ago' --no-pager | tail -20
#1723548264
echo $SHELL
#1723548340
tail -20 /var/log/syslog
#1723548405
ps -ef | head
#1723548470
ls -ltr /var/log/ | tail -10
#1723549697
exit
#1723549937
udevadm info --query=property --name=/dev/null | head
#1723550111
w
#1723553112
systemctl restart samba
#1723553122
journalctl -u samba -n 100
#1723553622
ps aux | grep samba
#1723553691
find /tmp -maxdepth 1 -type f | head
#1723553973
tail -20 ~/.bash_history
#1723553980
journalctl -u samba -n 20 --no-pager
